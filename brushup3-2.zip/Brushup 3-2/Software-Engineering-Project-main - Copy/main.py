from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL
import MySQLdb.cursors
import re

app = Flask(__name__)

# Change this to your secret key (can be anything, it's for extra protection)
app.secret_key = 'your secret key'

# Enter your database connection details below
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
#app.config['MYSQL_PASSWORD'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'test'

# Intialize MySQL
mysql = MySQL(app)



#@app.route('/')
#def home():
    #return render_template('home.html')

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    # Output message if something goes wrong...
    msg = ''
    # Check if "username", "password" and "email" POST requests exist (user submitted form)
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form and 'email' in request.form:
        # Create variables for easy access

        username = request.form['user']
        password = request.form['pword']
        first_name = request.form['fname']
        middle_initial = request.form['middle']
        last_name = request.form['lname']
        email = request.form['email']
        phone_number = request.form['phone']
        job_title = request.form['jobSelect']
        security_question_one = request.form['answer1']
        security_question_two = request.form['answer2']

        # Check if account exists using MySQL
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM USER  WHERE username = %s AND email = %s', (username, email,))
        account = cursor.fetchone()
        # If account exists show error and valIDation checks
        if account:
            msg = 'Account already exists!'
        elif not re.match(r'[^@]+@[^@]+\.[^@]+', email):
            msg = 'InvalID email address!'
        elif not username or not password or not email:
            msg = 'Please fill out the form!'
        else:
            # Account doesnt exists and the form data is valID, now insert new account into accounts table
            cursor.execute('INSERT INTO USER (User,pword,fname,middle,lname,email,phone,jobSelect,anwer1,answer2) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)',
                            (username, password, first_name, middle_initial, last_name, email, phone_number, job_title, security_question_one, security_question_two))
            mysql.connection.commit()
            #added below
            cursor.close()
            session["message"] = 'You Have Successfully Registered!'
            return redirect("/home")


    else:

        message = ""
        if session.get("message"):
            message = session.get("message")
            session.pop("message", None)

        return render_template('register.html', message=message)



    #return redirect(url_for('register'))

@app.route('/forgot')
def forgot():
    return render_template('forgot.html')

@app.route('/jobreport', methods =['GET', 'POST'])
def jobreport():
    if request.method == 'POST':
        #fetch form data
        userDetails = request.form
        customer_name = userDetails['custName']
        Customer_address = userDetails['address']
        Job_description = userDetails['jobDesc']
        proposedCost = userDetails['pcost']
        #now need to connect it to database and store it

        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO jobreport(customer_name, Customer_address,Job_description,proposedCost) VALUES(%s, %s, %s)" , ( customer_name, Customer_address,Job_description,proposedCost))
        mysql.connection.commit()
        cur.close()
        return 'sucess'
    return render_template('jobreport.html')


@app.route('/viewreport')
def viewreport():

    cur = mysql.connection.cursor()
    resultValue = cur.execute("SELECT * FROM jobreport")
    if resultValue > 0:
        userDetails = cur.fetchall()
        return render_template('viewreport.html', userDetails=userDetails)




if __name__ == '__main__':
    app.run(debug=True)