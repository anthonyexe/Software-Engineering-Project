from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL
import MySQLdb.cursors
import re

app = Flask(__name__)

# Change this to your secret key (can be anything, it's for extra protection)
app.secret_key = 'your secret key'

# Enter your database connection details below
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
#app.config['MYSQL_PASSWORD'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'test'

# Intialize MySQL
mysql = MySQL(app)



#@app.route('/')
#def home():
    #return render_template('home.html')

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/register', methods =['GET', 'POST'])
def register():
    if request.method == 'POST':
        # fetch form data
        regDetails = request.form
        username = regDetails['user']
        first_name = regDetails['fname']
        middle_initial = regDetails['middle']
        last_name = regDetails['lname']
        email = regDetails['email']
        phone_number = regDetails['phone']
        job_title = regDetails['jobSelect']
        password = regDetails['pword']
        security_question_one = regDetails['answer1']
        security_question_two = regDetails['answer2']

        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO user(username, first_name, middle_initial, last_name,email, phone_number, job_title, password, security_question_one, security_question_two) VALUES(%s, %s, %s,%s, %s, %s,%s, %s, %s, %s)" , (username, first_name, middle_initial, last_name,email, phone_number, job_title, password, security_question_one, security_question_two))
        mysql.connection.commit()
        cur.close()
        return 'Account Sucessfully Created'
    return render_template('register.html')

@app.route('/jobreport', methods =['GET', 'POST'])
def jobreport():
    if request.method == 'POST':
        #fetch form data
        userDetails = request.form
        customer_name = userDetails['custName']
        Customer_address = userDetails['address']
        Job_description = userDetails['jobDesc']
        jobCost = userDetails['pcost']
        #now need to connect it to database and store it

        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO jobreport(customer_name, Customer_address,Job_description,jobCost) VALUES(%s, %s, %s, %s)" , ( customer_name, Customer_address,Job_description,jobCost))
        mysql.connection.commit()
        cur.close()
        return render_template('reportSucess.html')
    return render_template('jobreport.html')





@app.route('/forgot')
def forgot():
    return render_template('forgot.html')




@app.route('/viewreport')
def viewreport():

    cur = mysql.connection.cursor()
    resultValue = cur.execute("SELECT * FROM jobreport")
    if resultValue > 0:
        userDetails = cur.fetchall()
        return render_template('viewreport.html', userDetails=userDetails)

    @app.route('/reportSucess')
    def reportSucess():

        cur = mysql.connection.cursor()
        resultValue = cur.execute("SELECT * FROM jobreport")
        if resultValue > 0:
            userDetails = cur.fetchall()
            return render_template('reportSucess.html', userDetails=userDetails)
        #cursor.lastrowid







if __name__ == '__main__':
    app.run(debug=True)